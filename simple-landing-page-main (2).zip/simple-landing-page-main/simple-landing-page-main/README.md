# Simple Landing Page

![simple-landing-page](img/simple-landing-page.png)

Projeto de uma página web simples, utilizando HTML e CSS.

## 🚀 Descrição

Projeto web de uma página de apresentação simples, desenvolvido utilizando HTML e CSS.
O objetivo é aprender mais sobre a construção de páginas web e implementar novas melhorias de forma incremental para uma página de apresentação.
Para a hospedagem do projeto foi utilizado o GitHub Pages.


### 👓 Visualizar

A aplicação simple-landing-page pode ser acessada pelo link:

* [simple landing page](https://wellfernandes.github.io/simple-landing-page/) - Aplicação simple-landing-page em produção. 

---
[Linkedin](https://www.linkedin.com/in/wellitonfernandes/) 😊